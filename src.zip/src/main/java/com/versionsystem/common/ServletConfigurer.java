package com.versionsystem.common;

public class ServletConfigurer {

}
